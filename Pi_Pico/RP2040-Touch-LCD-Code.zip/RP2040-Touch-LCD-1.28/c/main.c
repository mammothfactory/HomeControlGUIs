﻿#include "LCD_Test.h"   //Examples

int main(void)
{

    LCD_1in28_test();

    return 0;
}
